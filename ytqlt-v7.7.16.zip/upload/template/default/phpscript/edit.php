<?php
if (!defined('puyuetian'))
	exit('403');

$_G['TEMPLATE']['BODY'] = 'edit';
