<?php
if (!defined('puyuetian'))
	exit('403');

LoadAppScript();