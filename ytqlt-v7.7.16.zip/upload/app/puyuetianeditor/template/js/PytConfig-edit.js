var PytConfig;
//全部加载
PytConfig = 'Html,Bold,Italic,Underline,Strikethrough,Fontname,Fontsize,Forecolor,Backcolor,Justifyleft,Justifycenter,Justifyright,Link,Unlink,Emotion,Image,File,Undo,Redo';