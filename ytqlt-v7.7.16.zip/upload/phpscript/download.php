<?php
if (!defined('puyuetian'))
	exit('403');

header('Location:http://2.hadsky.com/index.php?' . $_SERVER['QUERY_STRING']);
//exit('Location:http://2.hadsky.com/' . $_SERVER['QUERY_STRING']);
