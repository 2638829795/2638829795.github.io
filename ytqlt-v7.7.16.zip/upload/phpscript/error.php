<?php
if (!defined('puyuetian'))
	exit('403');

$_G['TEMPLATE']['HEAD'] = 'null';
$_G['TEMPLATE']['BODY'] = 'error';
$_G['TEMPLATE']['FOOT'] = 'null';

$_G['SET']['WEBTITLE'] = '您找的页面不存在鸟~~~';
